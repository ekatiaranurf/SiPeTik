/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sipetik;

/**
 *
 * @author Eka Tiara
 */
public interface internal {
    public void setCode();
    public void simpanData();
    public void clear();
    public void showData();
}

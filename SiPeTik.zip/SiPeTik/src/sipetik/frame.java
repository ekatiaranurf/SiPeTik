/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sipetik;

/**
 *
 * @author Chynthia
 */
public class frame {
    public static Login flogin = new Login();
    public static Masuk fmenu = new Masuk();
    public static FPegawai pegawai = new FPegawai();
    public static FBatik batik = new FBatik();
    public static FPemasok pemasok = new FPemasok();
    public static FTransaksi transaksi = new FTransaksi();
}
